<?php
$form = get_sub_field('fields');

?>
	<div class="container">
	    <div class="row form-section">
			<div class="col-lg-3">

			</div>
			<div class="col-lg-6 form2 mt-5">
				 <div class="row">
					<div class="col-3" style="padding: 0px;text-align:right;">
						<img class="form-logo" style="height:100px;" src="<?php echo $form['logo']['url']; ?>"> 
					</div>
				<div class="col-lg-9" style="align-self: center;">
					 <p class="logo-title" style="color:white; font-weight:500; font-size:15px; line-height:18px; padding-top:10px;"><?php echo $form['description']; ?></p>
				</div>
			</div>		
				
			<div class="col-lg-3">
						
			</div>
        </div>
    </div>
</div>
					